package io.zby.bookstore.exceptions;

public class UserAlreadyExistException extends Exception {
}
