package io.zby.bookstore.repositories;

import io.zby.bookstore.entities.Cart;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

@RepositoryRestResource
@Repository
public interface CartRepository extends CrudRepository<Cart, Long> {
    @RestResource(exported = false)
    @Override
    Iterable<Cart> findAll();

    @RestResource(path = "searchByOwner", rel = "searchByOwner")
    Cart findByOwnerId(@Param("owner") Long ownerId);
}
