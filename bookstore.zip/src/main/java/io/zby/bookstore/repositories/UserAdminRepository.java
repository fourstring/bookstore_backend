package io.zby.bookstore.repositories;

import io.zby.bookstore.entities.User;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

@RepositoryRestResource(path = "admin_users")
@Repository
public interface UserAdminRepository extends PagingAndSortingRepository<User, Long> {
}
