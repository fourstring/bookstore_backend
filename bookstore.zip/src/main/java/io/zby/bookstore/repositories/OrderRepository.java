package io.zby.bookstore.repositories;

import io.zby.bookstore.entities.Order;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

@RepositoryRestResource
@Repository
public interface OrderRepository extends CrudRepository<Order, Long> {
    @RestResource(exported = false)
    @Override
    Iterable<Order> findAll();
}
