package io.zby.bookstore.controllers;

import io.zby.bookstore.dtos.LoginDTO;
import io.zby.bookstore.dtos.RegisterDTO;
import io.zby.bookstore.entities.User;
import io.zby.bookstore.exceptions.UserAlreadyExistException;
import io.zby.bookstore.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;

@RestController
public class AuthController {
    private UserService userService;

    @Autowired
    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public @ResponseBody
    User login(@RequestBody @Valid LoginDTO loginDTO) {
        return this.userService.login(loginDTO);
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity<Void> register(@RequestBody @Valid RegisterDTO registerDTO) {
        try {
            this.userService.register(registerDTO);
        } catch (UserAlreadyExistException uaeEx) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
