package io.zby.bookstore.constants;

public enum UserStatus {
    active,
    disabled
}
