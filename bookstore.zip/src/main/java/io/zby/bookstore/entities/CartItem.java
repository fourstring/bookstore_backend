package io.zby.bookstore.entities;

import javax.persistence.*;

@Entity
@Table(name = "T_CART_ITEM")
public class CartItem extends BaseProductItem {
    private Cart cart;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn
    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
}
