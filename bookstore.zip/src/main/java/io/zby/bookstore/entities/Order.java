package io.zby.bookstore.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "T_ORDER")
public class Order extends BaseEntity {
    private User createdUser;
    private List<OrderItem> items;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn
    public User getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(User createdUser) {
        this.createdUser = createdUser;
    }

    @OneToMany(mappedBy = "order", fetch = FetchType.EAGER)
    public List<OrderItem> getItems() {
        return items;
    }

    public void setItems(List<OrderItem> items) {
        this.items = items;
    }
}
