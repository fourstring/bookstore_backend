package io.zby.bookstore.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "T_CART")
public class Cart extends BaseEntity {
    private List<CartItem> items;
    private User owner;

    @OneToMany(mappedBy = "cart", fetch = FetchType.EAGER)
    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    @OneToOne(cascade = CascadeType.REMOVE)
    @JoinColumn
    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }
}
