package io.zby.bookstore.entities;

import javax.persistence.*;

@Entity
@Table(name = "T_ORDER_ITEM")
public class OrderItem extends BaseProductItem {
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "`order`")
    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}
